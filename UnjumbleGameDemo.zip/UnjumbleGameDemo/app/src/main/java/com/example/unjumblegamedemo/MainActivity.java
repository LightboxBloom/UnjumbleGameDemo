package com.example.unjumblegamedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    String userAnswer = "";     //Users answers will be stored in this string
    String correctAnswer = "she is a kind girl";    //Users answer will be compared to this string

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);

        TextView textView1 = findViewById(R.id.textView);
        textView1.setText("");

        shuffle(button1, button2, button3, button4, button5); //calling shuffle method

    }

    public void shuffle(Button a, Button b, Button c, Button d, Button e){  //shuffle method randomises which buttons will have which word on them

        String[] words = {"she", "is", "a", "kind", "girl"};
        List<String> shuffleList = Arrays.asList(words);
        Collections.shuffle(shuffleList);
        a.setText(shuffleList.get(0));
        b.setText(shuffleList.get(1));
        c.setText(shuffleList.get(2));
        d.setText(shuffleList.get(3));
        e.setText(shuffleList.get(4));

    }

    @Override
    public void onClick(View v) {   //handles the click events for all the buttons

        TextView textView1 = findViewById(R.id.textView);
        switch (v.getId()) {
            case R.id.button1:
                Button btn = findViewById(R.id.button1);
                btn.setEnabled(false);

                userAnswer = userAnswer + " " + btn.getText().toString();
                textView1.setText(userAnswer);
                break;

            case R.id.button2:
                Button btn2 = findViewById(R.id.button2);
                btn2.setEnabled(false);

                userAnswer = userAnswer + " " + btn2.getText().toString();
                textView1.setText(userAnswer);


                break;

            case R.id.button3:
                Button btn3 = findViewById(R.id.button3);
                btn3.setEnabled(false);

                userAnswer = userAnswer + " " + btn3.getText().toString();
                textView1.setText(userAnswer);
                break;

            case R.id.button4:
                Button btn4 = findViewById(R.id.button4);
                btn4.setEnabled(false);

                userAnswer = userAnswer + " " + btn4.getText().toString();
                textView1.setText(userAnswer);
                break;

            case R.id.button5:

                Button btn5 = findViewById(R.id.button5);
                btn5.setEnabled(false);

                userAnswer = userAnswer + " " + btn5.getText().toString();
                textView1.setText(userAnswer);
                break;


            case R.id.button6:

                if (userAnswer.contains(correctAnswer)) { //handles event when the user gives correct answer
                    Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
                } else{                                   //handles event when the user gives incorrect answer
                    Toast.makeText(this, "Incorrect. Use all available words or click RESTART to try again", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.button7:
                Toast.makeText(this, "Game Restarted", Toast.LENGTH_SHORT).show();
                userAnswer = "";
                textView1.setText(userAnswer);

                Button btnOne = findViewById(R.id.button1);
                btnOne.setEnabled(true);

                Button btnTwo = findViewById(R.id.button2);
                btnTwo.setEnabled(true);

                Button btnThree = findViewById(R.id.button3);
                btnThree.setEnabled(true);

                Button btnFour = findViewById(R.id.button4);
                btnFour.setEnabled(true);

                Button btnFive = findViewById(R.id.button5);
                btnFive.setEnabled(true);

                shuffle(btnOne, btnTwo, btnThree, btnFour, btnFive);

                break;

        }
    }
}